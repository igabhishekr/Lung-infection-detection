# Lung Disease Prediction Using Deep Learning

## 📌 Overview
This project aims to classify **chest X-ray images** to detect various lung diseases using a **deep learning-based Convolutional Neural Network (CNN)** model. The model can predict whether an X-ray belongs to one of the following categories:
- **Normal**
- **COVID-19**
- **Lung Opacity**
- **Viral Pneumonia**

The application is built using **Flask** for deployment and allows users to upload X-ray images for real-time disease classification.

---
## 🚀 Features
- **Deep Learning-based Classification** using a trained CNN model
- **Flask Web Application** for easy user interaction
- **Automated Image Preprocessing** (Resizing, Normalization)
- **Fast and Accurate Predictions**
- **User-Friendly Interface**

---
## 📂 Dataset
The dataset used for training consists of **chest X-ray images** sourced from public repositories such as:
- **COVID-19 Radiography Database (Kaggle)**
- **NIH Chest X-ray Dataset**

---
## 🛠️ Tech Stack
- **Python 3.12**
- **TensorFlow / Keras** for deep learning model
- **Flask** for web deployment
- **NumPy, Skimage, OpenCV** for image processing
- **HTML, CSS, JavaScript** for the frontend

---
## ⚙️ Installation & Setup
### **1️⃣ Clone the Repository**
```sh
git clone https://github.com/your-repo/lung-disease-prediction.git
cd lung-disease-prediction
```

### **2️⃣ Install Dependencies**
```sh
pip install -r requirements.txt
```

### **3️⃣ Run the Flask App**
```sh
python app.py
```
The application will start at `http://127.0.0.1:5000/`

---
## 🔬 Model Implementation
### **Preprocessing Steps:**
- Convert image to **NumPy array**
- Resize image to **150×150 pixels**
- Normalize pixel values to **[0,1] range**
- Expand dimensions for model input

### **Model Architecture:**
- **Conv2D + MaxPooling** layers for feature extraction
- **Flatten layer** to convert features to a dense representation
- **Dense layers with Softmax Activation** for c